﻿namespace CrudOperation.DAL
{
    public interface IUpdate
    {
        int UpdateEventDetail(int EventID, string EventName);
    }
}