﻿namespace CrudOperation.DAL
{
    public interface IDelete
    {
        int DeleteEventDetail(int EventID);
    }
}